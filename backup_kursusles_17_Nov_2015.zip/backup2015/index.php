<?php
	//TUTUP AKSES YANG MENGGUNAKAN URL
	echo "<script>window.location.href = 'http://kursusles.com/dev';</script>";
?>