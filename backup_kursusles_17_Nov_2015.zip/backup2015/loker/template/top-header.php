<div class="infoslogan text-right margin0" style="margin-top: 0 !important; font-family: Verdana,Arial,Helvetica,sans-serif;">
	<a href="APP_URLINDEX_USER" style="text-decoration:none; color: #eee;">
        <img src="APP_IMG_URLgenerate_pic.php?type=pr&q=IMG_PROFILE_ENCODE&w=32&h=32" class="img-circle" />
        Halo! <strong>PROFILE_NAME</strong>
   	</a>
   	<input class="btn btn-sm btn-custom2 margin03" value="LogOut" type="button" onclick="window.location.href = 'APP_URLlogout'">
</div>
