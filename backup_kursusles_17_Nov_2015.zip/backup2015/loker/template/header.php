TOP_HEADER
<div class="container">
    <div class="row top">
        <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
            <div class="logo">
                <img src="APP_IMG_URLlogo.png" class="img-responsive" alt="logo" />
            </div>
        </div>
        <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
            <div class="form-login pull-right">
            	LOGIN_FORM
            </div>
            <div class="menu">
                <nav class="navbar navbar-default">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar_kursusles">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="collapse navbar-collapse" id="navbar_kursusles">
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="APP_URLindex">HOME</a></li>
                                <li><a href="APP_URLINDEX_USER">PROFIL</a></li>
                                <li><a href="#">TIPS DUNIA KERJA</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</div>
<div class="blueslogan text-right">
    <div class="container">
        <h3> </h3>
    </div>
</div>