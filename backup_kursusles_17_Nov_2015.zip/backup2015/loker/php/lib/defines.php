<?php
	define("APP_BASE_URL", "http://kursusles.com/");
	define("APP_URL", "http://kursusles.com/loker/");
	define("APP_IMG_URL", "http://kursusles.com/dev/images/");
	define("APP_FONT_URL", "http://kursusles.com/dev/fonts/");
	
	define("GOOGLE_RECAPTCHA_URL", "https://www.google.com/recaptcha/");
	define("GOOGLE_RECAPTCHA_SITEKEY", "6LfaUwITAAAAAFaBBoco_rYlrNSUlAmpFY0NLgO_");
	define("GOOGLE_RECAPTCHA_SECRET", "6LfaUwITAAAAAObkFlGaib55L72osNKKrobm1Su9");
	define("GOOGLE_RECAPTCHA_LANG", "id");
?>