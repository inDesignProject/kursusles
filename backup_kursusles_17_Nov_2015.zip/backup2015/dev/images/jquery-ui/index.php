<?php
	//TUTUP AKSES YANG MENGGUNAKAN URL
	echo "404 - not found";
?>