<?php include "header.php";?>
		<div class="container">
			<h3 class="text-left text_kursusles page-header">TIPS DUNIA KERJA</h3>
			<div class="row">
				<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
					<div class="boxSquare">
						<div class="boxSquareWhite">
							<a href="#"><span class="tutor_name">Ini Judul Tutorial</span></a><br/>
							<small class="tutorial_detail"><i class="fa fa-calendar"></i> <?=date("d-m-Y");?> | <i class="fa fa-user"></i> admin</small>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</p>
							<a href="" class="label label-danger">Baca selengkapnya...</a>
						</div><br/>
						<div class="boxSquareWhite">
							<a href="#"><span class="tutor_name">Ini Judul Tutorial</span></a><br/>
							<small class="tutorial_detail"><i class="fa fa-calendar"></i> <?=date("d-m-Y");?> | <i class="fa fa-user"></i> admin</small>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</p>
							<a href="" class="label label-danger">Baca selengkapnya...</a>
						</div><br/>
						<div class="boxSquareWhite">
							<a href="#"><span class="tutor_name">Ini Judul Tutorial</span></a><br/>
							<small class="tutorial_detail"><i class="fa fa-calendar"></i> <?=date("d-m-Y");?> | <i class="fa fa-user"></i> admin</small>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</p>
							<a href="" class="label label-danger">Baca selengkapnya...</a>
						</div><br/>
						<div class="boxSquareWhite">
							<a href="#"><span class="tutor_name">Ini Judul Tutorial</span></a><br/>
							<small class="tutorial_detail"><i class="fa fa-calendar"></i> <?=date("d-m-Y");?> | <i class="fa fa-user"></i> admin</small>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</p>
							<a href="" class="label label-danger">Baca selengkapnya...</a>
						</div><br/>
						<div class="boxSquareWhite">
							<a href="#"><span class="tutor_name">Ini Judul Tutorial</span></a><br/>
							<small class="tutorial_detail"><i class="fa fa-calendar"></i> <?=date("d-m-Y");?> | <i class="fa fa-user"></i> admin</small>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
							</p>
							<a href="" class="label label-danger">Baca selengkapnya...</a>
						</div><br/>
						<nav>
							<ul class="pagination">
								<li class="disabled">
									<a href="#" aria-label="Previous">
										<span aria-hidden="true">&laquo;</span>
									</a>
								</li>
								<li class="active"><a href="#">1</a></li>
								<li><a href="#">2</a></li>
								<li><a href="#">3</a></li>
								<li><a href="#">4</a></li>
								<li><a href="#">5</a></li>
								<li>
									<a href="#" aria-label="Next">
										<span aria-hidden="true">&raquo;</span>
									</a>
								</li>
							</ul>
						</nav>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
					<div class="boxSquare">
						<div class="segmenPaket">
							<div class="panel panel-default">
								<div class="panel-heading">ARTIKEL TERBARU</div>
								<div class="panel-body list-group">
									<a href="#" class="list-group-item">Cras justo odio</a>
									<a href="#" class="list-group-item">Dapibus ac facilisis in</a>
									<a href="#" class="list-group-item">Morbi leo risus</a>
									<a href="#" class="list-group-item">Porta ac consectetur ac</a>
									<a href="#" class="list-group-item">Vestibulum at eros</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<?php include "footer.php";?>