<?php include "header.php";?>
		<div class="container">
			<h3 class="text-left text_kursusles page-header">TIPS DUNIA KERJA</h3>
			<div class="row">
				<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
					<div class="boxSquare">
						<div class="boxSquareWhite">
							<h3><span class="tutor_name">Ini Judul Tutorial</span></h3>
							<small class="tutorial_detail"><i class="fa fa-calendar"></i> <?=date("d-m-Y");?> | <i class="fa fa-user"></i> admin</small><hr>
							<p>
								Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum eu orci ultrices, consectetur massa vel, varius tortor. Praesent non ligula posuere, sagittis mi nec, aliquet diam. Etiam semper augue in bibendum ultricies. Vivamus vehicula leo vitae lorem sagittis luctus vel in enim. Sed scelerisque sed est id posuere. Duis feugiat bibendum enim, eget ornare lorem accumsan a. Quisque aliquam tortor vitae sem gravida congue. Vestibulum at mauris non lorem lacinia scelerisque mattis sed dolor. Mauris ultrices quam ac eros cursus faucibus. Morbi iaculis nulla mauris, sed feugiat justo interdum et.

								Aenean consectetur turpis ut neque gravida, lacinia tristique libero condimentum. Integer in nulla nibh. Sed accumsan est at elit condimentum, fringilla blandit enim commodo. Curabitur non dictum tellus. Donec consequat enim lobortis tempor hendrerit. Pellentesque cursus tristique nisl non placerat. Phasellus scelerisque magna dolor. Nam viverra rutrum nisi vitae vehicula. Aliquam id urna convallis, placerat ex maximus, interdum justo. Vivamus id varius enim. In molestie nulla nisi, in dictum nunc tempor faucibus. Sed mollis mauris quis hendrerit condimentum. Duis eget ex nunc. Praesent imperdiet tellus vitae tincidunt viverra. Cras auctor placerat mi, sit amet blandit diam vehicula ac. Vestibulum mollis id urna et molestie.

								Nunc vitae pharetra mi. Aliquam quam felis, fermentum at varius et, lobortis quis erat. In commodo nisl leo. Morbi a dignissim orci, ac tempor sapien. Nullam placerat pulvinar magna, fringilla semper velit malesuada ac. Donec facilisis nec nisi a eleifend. Integer aliquet rhoncus lacus, non tempor est mattis ac. Aliquam neque risus, varius et mollis non, tincidunt eget risus. Nunc dui neque, mollis ut enim sit amet, posuere tempus tellus. Aenean rhoncus luctus diam, id interdum ante viverra sit amet. Nullam dictum eros ut lorem faucibus, vitae pharetra odio interdum. In malesuada, ligula sed feugiat sollicitudin, eros neque elementum eros, at pharetra velit massa vel tellus. Suspendisse ac ligula lacinia, pulvinar lectus nec, volutpat felis. Morbi egestas sem sit amet dignissim accumsan. Quisque fringilla est in neque ullamcorper egestas.

								Maecenas vehicula quis velit nec congue. Quisque vestibulum quis erat vitae condimentum. In hac habitasse platea dictumst. Sed finibus quam diam, id congue felis eleifend ut. Aenean pretium nibh et lorem porta fringilla. Nullam vulputate rhoncus ante eget fringilla. Donec eget tortor ex. Vivamus ut sodales dolor, sit amet maximus velit. Quisque porttitor eu lacus sit amet tempus. Integer porttitor suscipit consectetur. Fusce venenatis ligula consectetur ex dictum pharetra. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.

								Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Interdum et malesuada fames ac ante ipsum primis in faucibus. Phasellus vehicula, eros a congue varius, felis ex eleifend orci, et ornare ex sapien sed ex. Curabitur feugiat commodo diam vitae accumsan. In hac habitasse platea dictumst. Mauris pulvinar non erat at convallis. Nullam tempor sem velit, vel maximus nisi mattis at. Aenean consequat ultrices dapibus. Curabitur dictum mi sit amet pulvinar laoreet. Fusce dapibus, eros non condimentum lobortis, leo mauris ultrices enim, at pulvinar quam mauris sed justo. Phasellus rhoncus imperdiet massa, quis consequat lectus sollicitudin sollicitudin.
							</p><hr>
							<ul class="list-inline">
								<li>Bagikan tutorial ini</li>
								<li><a href="http://www.facebook.com/sharer.php?u=<?=$escaped_link;?>" onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;" class="btn btn-primary btn-sm"><i class="fa fa-facebook"></i> Facebook</a></li>
								<li><a href="http://twitter.com/share?url=<?=$escaped_link;?>&text=Judul tutorial @KursusLes" onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;" class="btn btn-info btn-sm"><i class="fa fa-twitter"></i> Twitter</a></li>
								<li><a href="https://plus.google.com/share?url=<?=$escaped_link;?>" onclick="window.open(this.href, 'mywin','left=20,top=20,width=500,height=500,toolbar=1,resizable=0'); return false;" class="btn btn-danger btn-sm"><i class="fa fa-google-plus"></i> Google+</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
					<div class="boxSquare">
						<div class="segmenPaket">
							<div class="panel panel-default">
								<div class="panel-heading">ARTIKEL TERBARU</div>
								<div class="panel-body list-group">
									<a href="#" class="list-group-item">Cras justo odio</a>
									<a href="#" class="list-group-item">Dapibus ac facilisis in</a>
									<a href="#" class="list-group-item">Morbi leo risus</a>
									<a href="#" class="list-group-item">Porta ac consectetur ac</a>
									<a href="#" class="list-group-item">Vestibulum at eros</a>
								</div>
							</div>
						</div>
						<div class="segmenKeahlian">
							<div class="panel panel-default">
								<div class="panel-heading">TIPS TERKAIT</div>
								<div class="panel-body list-group">
									<a href="#" class="list-group-item">Cras justo odio</a>
									<a href="#" class="list-group-item">Dapibus ac facilisis in</a>
									<a href="#" class="list-group-item">Morbi leo risus</a>
									<a href="#" class="list-group-item">Porta ac consectetur ac</a>
									<a href="#" class="list-group-item">Vestibulum at eros</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
<?php include "footer.php";?>